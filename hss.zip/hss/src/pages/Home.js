import React from 'react';
import './Home.css';
import 'bootstrap/dist/css/bootstrap.css';
import logo from './logo.png';
import member from './member.png';
import saving from './saving.png';
import loan from './loan.png';
import bank from './bank.png';
import setting from './setting.png';
import report from './report.png';
import profile from './profile.jpeg';

function Home() {
  return (
    <>
          <div class="row  bg-dark">
          
          <div class="col-xl-1 col-lg-2 col-sm-2 col-3 ">

          <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                        <div class="container-fluid">
                         
                          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                            <span class="navbar-toggler-icon"></span>
                          </button>
                          <div class="collapse navbar-collapse" id="collapsibleNavbar">
                            <ul class="navbar-nav">
                              <li class="nav-item">
                                <a class="nav-link" href="#">SHG</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" href="#">Home</a>
                              </li>
                              <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Lang</a>
                                <ul class="dropdown-menu">
                                  <li><a class="dropdown-item" href="#">Hindi</a></li>
                                  <li><a class="dropdown-item" href="#">marathi</a></li>
                                  <li><a class="dropdown-item" href="#">English</a></li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </nav>
                                      
            </div>


            <div class="col-xl-10 col-lg-8 col-sm-8 col-6">
                    <a class="navbar-brand me-auto" href="#"> <img src={logo} className="App-logo" alt="logo" /></a>
                    </div>
              <div class="col-xl-1 col-lg-2 col-sm-2 col-3" >
                   
                    <li class="nav-item dropdown   me-auto">
                      <a class="nav-link dropdown-toggle bg-dark" href="#" role="button" data-bs-toggle="dropdown"> <img src={profile} className="profile"  alt="logo" /></a>
                      <ul class="dropdown-menu ">
                              <li><a class="dropdown-item" href="#">View Profile</a></li>
                              <li><a class="dropdown-item" href="#">Change Password</a></li>
                              <li><a class="dropdown-item" href="#">Log Out</a></li>
                    </ul>
                  </li>
              </div>
              
          
            </div>
      
      
  <div class="container-fluid  bg-primary" id="accordion" className='contain'>
      <div class="row" >
            <div class="col-xl-4 col-lg-6 col-sm-6 ">
                 <div className='Menus' id='menus1' data-bs-toggle="collapse" href="#list1">
                      
                      <img src={member} className="images" alt="logo" />
                      
                      <ul id='list1' class="collapse show" data-bs-parent="#accordion">
                            <li class="list-group-item list-group-item-action"><a href=''>Add Member</a></li>
                            <li class="list-group-item list-group-item-action"><a href=''>Delete Member</a></li>
                            <li class="list-group-item list-group-item-action"><a href=''>View All Members</a></li>
                            <li className='hide'>View All Members</li>
                      </ul>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-sm-6">
               <div className='Menus' id='menus2' data-bs-toggle="collapse" href="#list2">

                     <img src={saving} className="images" alt="logo" />
                    
                      <ul id='list2' class="collapse show" data-bs-parent="#accordion">
                            <li class="list-group-item list-group-item-action"><a href=''>Add Savings</a></li>
                            <li class="list-group-item list-group-item-action"><a href=''>View Total Savings</a></li>
                            <li className='hide'>View All Members</li>
                            <li className='hide'>View All Members</li>
                      </ul>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-sm-6">
                <div className='Menus' id='menus3' data-bs-toggle="collapse" href="#list3" >
                        
                        <img src={loan} className="images" alt="logo" />
                        
                        <ul id='list3' class="collapse show" data-bs-parent="#accordion">
                              <li class="list-group-item list-group-item-action"><a href=''>View Loan Requests</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>Add Loan Installment</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>View Active Loans</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>View Finished Loans</a></li>
                        </ul>
                </div>
            </div>          
          
    
          <div class="col-xl-4 col-lg-6 col-sm-6" >
             <div className='Menus' id='menus4' data-bs-toggle="collapse" href="#list4">

                    <img src={bank} className="images" alt="logo" />
                    
                    <ul id='list4'  class="collapse show" data-bs-parent="#accordion">
                              <li class="list-group-item list-group-item-action"><a href=''>Add Money Taken Details</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>Add Money Deposit Details</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>View Total money</a> </li>
                              <li className='hide'>View All Members</li>
                    </ul>
               </div>
          </div>
          <div class="col-xl-4 col-lg-6 col-sm-6">
              <div className='Menus' id='menus5' data-bs-toggle="collapse" href="#list5" >

                    <img src={setting} className="images" alt="logo" />
                    
                    <ul id='list5' class="collapse show" data-bs-parent="#accordion">
                              <li class="list-group-item list-group-item-action"><a href=''>Set Fields values</a></li>
                              <li className='hide'>View All Members</li>
                              <li className='hide'>View All Members</li>
                              <li className='hide'>View All Members</li>
                     </ul>
              </div>
          </div>
          <div class="col-xl-4 col-lg-6 col-sm-6">
              <div className='Menus' id='menus6' data-bs-toggle="collapse" href="#list6" >

                    <img src={report} className="images" alt="logo" />
                    
                    <ul id='list6' class="collapse show" data-bs-parent="#accordion">
                              <li class="list-group-item list-group-item-action"><a href=''>View Members Report</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>View total Interest Profit</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>View Monthy Profit</a></li>
                              <li class="list-group-item list-group-item-action"><a href=''>View End season report</a></li>
                    </ul>
              </div> 
          </div>

     </div>
  </div>

  <div class="container-fluid bg-primary" id="infor">
  <h1>My First Bootstrap Page</h1>
  <p>This part is inside a .container-fluid class.</p>
  <p>The .container-fluid class provides a full width container, spanning the entire width of the viewport.</p>     
</div>


<footer class="container-fluid bg-dark " id="info">
  <h1 className='ftext'>My First Bootstrap Page</h1>
  
</footer>



</>
    

  );
}

export default Home;
