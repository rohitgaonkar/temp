import logo from '../logo.png';
import './Login.css';
import 'bootstrap/dist/css/bootstrap.css';
import { useState } from 'react';


function Login() {

  const [opff,setOpff]=useState();

  if(opff==='option1'){

    document.getElementById("sign").style.visibility='visible';

    
  }

  if(opff==='option2'){

    document.getElementById("sign").style.visibility='hidden';

  }

  return (
    <div class="vh-100 d-flex justify-content-center align-items-center">
    <div class="container">
      <div class="row d-flex justify-content-center">
        <div class="col-12 col-md-8 col-lg-6">
          <div class="card  gradient-custom-2">
            <div class="card-body p-5">
              <form class="mb-3 mt-md-4">
                      
                <div class="mb-3" className='logo'>
                    <img src={logo} className="image" alt="logo" />
                </div>

                <div class="mb-3">
                  <label for="email" class="form-label ">Email address</label>
                  <input type="email" class="form-control" id="email" placeholder="name@example.com"/>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label ">Password</label>
                  <input type="password" class="form-control" id="password" placeholder="*******"/>
                </div>

                <div class="mb-3">
                     <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1"  onChange={e=>setOpff(e.target.value) } defaultChecked/>
                      <label class="form-check-label" for="inlineRadio1">Admin</label>
                    </div>
                    <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" onChange={e=>setOpff(e.target.value)}/>
                      <label class="form-check-label" for="inlineRadio2">Member</label>
                    </div>
                   
                </div>

                <p class="small" id='forgot'><a class="text-primary" href="forget-password.html">Forgot password?</a></p>
                
                <div class="d-grid">
                  <button class="btn btn-outline-dark" type="submit">Login</button>
                </div>
              </form>
              <div id='sign'>
              
                <p class="mb-0  text-center">Don't have an account? <a href="signup.html" class="text-primary fw-bold">Sign
                    Up</a></p>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  );
}
export default Login;       