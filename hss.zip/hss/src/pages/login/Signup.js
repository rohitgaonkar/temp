import logo from '../logo.png';
import './Signup.css';
import 'bootstrap/dist/css/bootstrap.css';
import { useState } from 'react';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth,db} from '../../Firebase';

function Signup() {

    const [name,setName]=useState('');
    const [email,setEmail]=useState('');
    const [pass,setPass]=useState('');
    const [repass,setRepass]=useState('');
    const [lname,setLname]=useState('');
    const [addr,setAddr]=useState('');
    const [stat,setStat]=useState('');
    const [city,setCity]=useState('');
    const [pin,setPin]=useState('');
    const [shg,setShg]=useState('');
    const [num,setNum]=useState('');

    const [errmsg,setErrmsg]=useState('');
    const [errpass,setErrpass]=useState('');


    const handleSubmition=(e)=>{
        e.preventDefault(); 
        db.collection("users").doc("userid").set({
            username: 'name',
            password: '345', 
            email: 'ghjk', 
            age: 'ertyu' 
        })
        
          if(!name || !lname || !addr || !pass || !repass || !num || !email || !stat || !city || !pin || !shg){
               setErrmsg("Fill All The Fields");
               return;
          }
          setErrmsg("");
          
          
          if(pass!==repass){
              
            setErrpass("Both password is not Same");
            return; 
          }
          
        setErrpass("");


        
        createUserWithEmailAndPassword(auth, email, pass,name,addr,stat,lname,city,shg,num,pin)
          .then((userCredential) => {
            // Signed in 
            const user = userCredential.user;
            // ...
          })
          .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            // ..
          });
       
   };
  
 
  
  

  return (
      <div class='container gradient-custom-2 '>
          <div class='row'>
          <center>
          <img src={logo} className="imagess" alt="logo" />
          
              
          
          <div class='container-fluid '>
      
              <h1 className='heading'> SignUp form</h1>
         
          </div>
          </center>
          </div>
    <form id="theForm" class="row g-2 mt-5 ">
                <div class="col-sm-6">
                    <label for="fname" class="form-label" >First Name</label>
                    <input type="text" class="form-control" id="fname" onChange={e=>setName(e.target.value)}required/>
                </div>
                <div class="col-sm-6">
                    <label for="lname" class="form-label">Last Name</label>
                    <input type="text" class="form-control" id="lname" onChange={e=>setLname(e.target.value)}required/>
                </div>
                <div class="col-md-6">
                    <label for="inputEmail4" class="form-label">Email</label>
                    <input type="email" class="form-control " id="inputEmail4" onChange={e=>setEmail(e.target.value)} required/>
                </div>
                <div class="col-md-6">
                    <label for="mobile" class="form-label">Mobile Number</label>
                    <input type="text" class="form-control " id="mobile" onChange={e=>setNum(e.target.value)}required/>
                </div>
                <div class="col-md-6">
                    <label for="inputPassword4" class="form-label">Password  </label>
                    <input type="password" class="form-control" id="inputPassword4"  onChange={e=>setPass(e.target.value)}required/>
                </div>
                <div class="col-md-6">
                    <label for="inputPassword5" class="form-label">Re-Enter Password</label>
                    <input type="password" class="form-control" id="inputPassword5" onChange={e=>setRepass(e.target.value)} required/>
                </div>
                <div class="col-12">
                    <label for="inputAddress" class="form-label">Address</label>
                    <input type="text" class="form-control" id="inputAddress"  onChange={e=>setAddr(e.target.value)} required/>
                </div>
                <div class="col-md-3">
                    <label for="state" class="form-label">State</label>
                    <input type="text" class="form-control" id="state" onChange={e=>setStat(e.target.value)} required/>
                </div>
                <div class="col-md-3">
                    <label for="inputCity" class="form-label">City</label>
                    <input type="text" class="form-control" id="city" onChange={e=>setCity(e.target.value)} required/>
                </div>
                <div class="col-md-3">
                    <label for="shg" class="form-label">Self Help group Name</label>
                    <input type="text" class="form-control" id="shg" onChange={e=>setShg(e.target.value)} required/>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="pin" class="form-label">Pin Code</label>
                    <input type="text" class="form-control" id="pin" onChange={e=>setPin(e.target.value)} required/>
                </div>
                <div class="col-md-3 mb-3">
                    <b className="err"> {errmsg} {errpass}</b>
                    
               
                </div>
                
                <div class="col-12 mb-3">
                    
                <button onClick={handleSubmition} type="submit" class="btn btn-primary"  > Sign in</button>
                </div>
  </form>

  </div>
  );
}

export default Signup;
