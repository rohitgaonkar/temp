import React from 'react';
import './Demo.css';
import 'bootstrap/dist/css/bootstrap.css';
import logo from './logo.png';
import member from './member.png';
import saving from './saving.png';
import loan from './loan.png';
import bank from './bank.png';
import setting from './setting.png';
import report from './report.png';
import profile from './profile.jpeg';

function Demo() {
  return (
    <>
          <div class="row  bg-dark">
          
          <div class="col-xl-1 col-lg-2 col-sm-2 col-3 ">

          <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                        <div class="container-fluid">
                         
                          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                            <span class="navbar-toggler-icon"></span>
                          </button>
                          <div class="collapse navbar-collapse" id="collapsibleNavbar">
                            <ul class="navbar-nav">
                              <li class="nav-item">
                                <a class="nav-link" href="#">SHG</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" href="#">Demo
                            </a>
                              </li>
                              <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Lang</a>
                                <ul class="dropdown-menu">
                                  <li><a class="dropdown-item" href="#">Hindi</a></li>
                                  <li><a class="dropdown-item" href="#">marathi</a></li>
                                  <li><a class="dropdown-item" href="#">English</a></li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </nav>
                                      
            </div>


            <div class="col-xl-10 col-lg-8 col-sm-8 col-6">
                    <a class="navbar-brand me-auto" href="#"> <img src={logo} className="App-logo" alt="logo" /></a>
                    </div>
              <div class="col-xl-1 col-lg-2 col-sm-2 col-3" >
                   
                    <li class="nav-item dropdown   me-auto">
                      <a class="nav-link dropdown-toggle bg-dark" href="#" role="button" data-bs-toggle="dropdown"> <img src={profile} className="profile"  alt="logo" /></a>
                      <ul class="dropdown-menu ">
                              <li><a class="dropdown-item" href="#">View Profile</a></li>
                              <li><a class="dropdown-item" href="#">Change Password</a></li>
                              <li><a class="dropdown-item" href="#">Log Out</a></li>
                    </ul>
                  </li>
              </div>
        </div>
            
        
            <div class="container bg-primary gradient-custom-2 ">
            <h1>Add Member Form</h1>   
          
             </div>

<footer class="col-12 bg-dark" id="info">
  <h1 className='ftext'>My First Bootstrap Page</h1>
</footer>

</>
    

  );
}

export default Demo;
