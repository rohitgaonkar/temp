import React from 'react';
import './AddMember.css';
import 'bootstrap/dist/css/bootstrap.css';
import logo from './logo.png';

import profile from './profile.jpeg';

function AddMember() {
  return (
    <>
          <div class="row  bg-dark">
          
          <div class="col-xl-1 col-lg-2 col-sm-2 col-3 ">

          <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
                        <div class="container-fluid">
                         
                          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                            <span class="navbar-toggler-icon"></span>
                          </button>
                          <div class="collapse navbar-collapse" id="collapsibleNavbar">
                            <ul class="navbar-nav">
                              <li class="nav-item">
                                <a class="nav-link" href="#">SHG</a>
                              </li>
                              <li class="nav-item">
                                <a class="nav-link" href="#">AddMember
                            </a>
                              </li>
                              <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Lang</a>
                                <ul class="dropdown-menu">
                                  <li><a class="dropdown-item" href="#">Hindi</a></li>
                                  <li><a class="dropdown-item" href="#">marathi</a></li>
                                  <li><a class="dropdown-item" href="#">English</a></li>
                                </ul>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </nav>
                                      
            </div>


            <div class="col-xl-10 col-lg-8 col-sm-8 col-6">
                    <a class="navbar-brand me-auto" href="#"> <img src={logo} className="App-logo" alt="logo" /></a>
                    </div>
              <div class="col-xl-1 col-lg-2 col-sm-2 col-3" >
                   
                    <li class="nav-item dropdown   me-auto">
                      <a class="nav-link dropdown-toggle bg-dark" href="#" role="button" data-bs-toggle="dropdown"> <img src={profile} className="profile"  alt="logo" /></a>
                      <ul class="dropdown-menu ">
                              <li><a class="dropdown-item" href="#">View Profile</a></li>
                              <li><a class="dropdown-item" href="#">Change Password</a></li>
                              <li><a class="dropdown-item" href="#">Log Out</a></li>
                    </ul>
                  </li>
              </div>
        </div>
            
        
            <div class="container bg-primary gradient-custom-2 ">
            <h1>Add Member Form</h1>
            <div class="form">
                      <table colspan="2" align="center">
                      <td>First Name</td>
                      <td><input type="text" name="FirstName" placeholder="Enter youmer first name" /></td>
                      <tr>
                      <td>Joining Date</td>
                      <td><input type="text" name="JoiningDate" placeholder="Enter joining date" /></td>
                      </tr>
                      <tr>
                      <td>Mobile number</td>
                      <td><input type="text" name="mobilenumber" placeholder="Enter mobile number" /></td>
                      </tr>
                      <tr>
                      <td>Date of Birth</td>
                      <td><input type="text" name="dof" placeholder="Enter your birth date" /></td>
                      </tr>
                      <tr>
                      <td>Email-Id</td>
                      <td><input type="text" name="email" placeholder="Enter email id" /></td>
                      </tr>
                      <tr>
                      <td>Addhar number</td>
                      <td><input type="text" name="addhar" placeholder="Enter addhar card number" /></td>
                      </tr>
                      <tr>
                      <td>Address</td>
                      <td><input type="text" name="address" placeholder="Enter your address" /></td>
                      </tr>
                      <tr>
                      <td>Nominee name</td>
                      <td><input type="text" name="nominee" placeholder="Enter nominee name" /></td>
                      </tr>
                      <tr>
                      <td>Relation</td>
                      <td>
                        <select name="relation" id="relation">
                          <option value=" ">Select</option>
                          <option value="self">Self</option>
                          <option value="parent">Parent</option>
                          <option value="guardian">Guardian</option>
                        </select>
                      </td>
                      </tr>
                      <tr>
                      <button type="button" class="btn btn-primary">Add Member</button>
                      </tr>
                      </table>
          </div>



     </div>

<footer class="col-12 bg-dark" id="info">
  <h1 className='ftext'>My First Bootstrap Page</h1>
</footer>

</>
    

  );
}

export default AddMember;
